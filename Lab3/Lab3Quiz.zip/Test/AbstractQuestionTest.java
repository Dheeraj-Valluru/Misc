/**
 * Abstract Question test class that is able to make a constructor with no inputs and produce
 * a longrandom.
 */
public class AbstractQuestionTest {

  /**
   * This constructor takes no inputs and is meant to specify the longRandom variable.
   */
  protected AbstractQuestionTest() {
    String longRandom;
    longRandom = "aosdifjaso oifhas;ldihv;al skdfha;osidghv;osiadhvbasdjkhvn";
  }

}